from setuptools import setup, find_packages

setup(
    name="genialntools",
    version="3.0.0",
    description="Simple tools for slowing down or speeding up function execution",
    author="NEFOR",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.7",
)