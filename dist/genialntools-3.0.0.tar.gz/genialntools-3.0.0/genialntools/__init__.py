from .genial import Slowed, Speed

__all__ = ["Slowed", "Speed"]